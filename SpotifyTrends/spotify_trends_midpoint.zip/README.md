# Our final project for the iOS dev class, which displays a user's most-listened to music and trends using the Spotify API.

### To do: 1. Get the endpoints for get/post requests. 2. Create the swift file with the object to represent the response 3. Write out the get request 4. Use the info in our display
So far, our app logs in using the Spotify API and displays a screen depending on the time period you pick. We still need to write our get request, after which we wlll conver the JSON output from the get request to data we use on the screen. We also are going to refine our visuals. 
